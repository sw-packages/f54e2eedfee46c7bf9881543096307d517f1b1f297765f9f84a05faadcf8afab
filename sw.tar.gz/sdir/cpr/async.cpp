#include "cpr/async.h"

namespace cpr {

// NOLINTNEXTLINE (cppcoreguidelines-avoid-non-const-global-variables)
CPR_SINGLETON_IMPL(GlobalThreadPool)

} // namespace cpr
